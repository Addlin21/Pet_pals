package petpal.dao;

public interface DonationDao {
	void recordCashDonation(String donorName, double amount);
	void recordItemDonation(String donorName, double estimatedValue, String itemType);

}
