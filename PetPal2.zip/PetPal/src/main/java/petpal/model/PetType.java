package petpal.model;

public enum PetType {
	DOG, CAT

}
