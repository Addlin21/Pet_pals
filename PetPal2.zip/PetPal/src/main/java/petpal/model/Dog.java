package petpal.model;

import lombok.*;
import java.time.LocalDate;
import java.util.*;


@Getter
@Setter
@NoArgsConstructor
@ToString(callSuper = true)
public class Dog extends Pet {
    private String dogBreed;

    public Dog(String name, int age, String breed, String dogBreed) {
    	super(name, age, breed, PetType.DOG);
        this.dogBreed = dogBreed;
    }
}
