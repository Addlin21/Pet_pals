package petpal.main;

import petpal.model.*;
import petpal.dao.*;

import java.time.LocalDate;
import java.util.List;
import java.util.Scanner;

public class PetsMain {
	public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        PetShelter shelter = new PetShelter();
        AdoptionEvent event = new AdoptionEvent();
        IPetDao petDao = new PetDaoImpl();
        DonationDao donationDao = new DonationDaoImpl();
        AdoptionEventDao eventDao = new AdoptionEventDaoImpl();

        boolean running = true;
        while (running) {
            System.out.println("\n--- PetPals Menu ---");
            System.out.println("1. Add Pet");
            System.out.println("2. Remove Pet");
            System.out.println("3. List Available Pets");
            System.out.println("4. Record Cash Donation");
            System.out.println("5. Record Item Donation");
            System.out.println("6. Register Participant for Event");
            System.out.println("7. Show Upcoming Events");
            System.out.println("8. Exit");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
            case 1:
                System.out.print("Enter pet type (dog/cat): ");
                String type = scanner.nextLine();
                System.out.print("Name: ");
                String name = scanner.nextLine();
                System.out.print("Age: ");
                int age = scanner.nextInt();
                scanner.nextLine();
                System.out.print("Breed: ");
                String breed = scanner.nextLine();
                Pet pet;
                if (type.equalsIgnoreCase("dog")) {
                    System.out.print("Dog Breed: ");
                    String dogBreed = scanner.nextLine();
                    pet = new Dog(name, age, breed, dogBreed);
                    pet.setPetType(PetType.DOG); // ✅ Set pet type
                } else {
                    System.out.print("Cat Color: ");
                    String catColor = scanner.nextLine();
                    pet = new Cat(name, age, breed, catColor);
                    pet.setPetType(PetType.CAT); // ✅ Set pet type
                }
                shelter.addPet(pet);
                petDao.addPet(pet);
                System.out.println("Pet added successfully.");
                break;
                
            case 2:
                System.out.print("Enter name of pet to remove: ");
                String petToRemoveName = scanner.nextLine();
                boolean removedFromDb = petDao.removePetByName(petToRemoveName);
                if (removedFromDb) {
                    // Optional: remove from in-memory shelter if syncing needed
                    shelter.setAvailablePets(petDao.getAvailablePets());
                    System.out.println("Pet removed successfully.");
                } else {
                    System.out.println("Pet not found or already removed.");
                }
                break;


                case 3:
                    List<Pet> availablePets = petDao.getAvailablePets();
                    shelter.setAvailablePets(availablePets); // <-- new line
                    if (availablePets.isEmpty()) {
                        System.out.println("No pets available at the moment.");
                    } else {
                        System.out.println("--- Available Pets ---");
                        for (Pet p : availablePets) {
                            System.out.println(p);
                        }
                    }
                    break;

                case 4:
                    System.out.print("Donor Name: ");
                    String donor = scanner.nextLine();
                    System.out.print("Amount: ");
                    double amount = scanner.nextDouble();
                    scanner.nextLine();
                    donationDao.recordCashDonation(donor, amount);
                    break;

                case 5:
                    System.out.print("Donor Name: ");
                    String itemDonor = scanner.nextLine();
                    System.out.print("Amount (estimated value): ");
                    double itemAmount = scanner.nextDouble();
                    scanner.nextLine(); // To consume the newline character left after nextDouble()
                    System.out.print("Item Type: ");
                    String itemType = scanner.nextLine();

                    // Record the item donation using the DonationDao
                    donationDao.recordItemDonation(itemDonor, itemAmount, itemType);  // 'donationitem' now
                    break;

                case 6:
                    System.out.print("Enter event ID: ");
                    int eventId = scanner.nextInt();
                    scanner.nextLine();  // Consume the newline left by nextInt()
                    
                    System.out.print("Enter participant name: ");
                    String participantName = scanner.nextLine();

                    // Register the participant by calling the registerParticipant method
                    eventDao.registerParticipant(eventId, participantName);
                    break;

                case 7:
                    // Fetch upcoming events using the eventDao
                    List<String> events = eventDao.getUpcomingEvents();

                    // Check if there are any events to display
                    if (events.isEmpty()) {
                        System.out.println("No upcoming events found.");
                    } else {
                        // Print out the events
                        System.out.println("--- Upcoming Events ---");
                        events.forEach(System.out::println);
                    }
                    break;




                case 8:
                    running = false;
                    System.out.println("Exiting PetPals. Goodbye!");
                    break;

                default:
                    System.out.println("Invalid choice. Try again.");
            }
        }
        scanner.close();
    }

}
