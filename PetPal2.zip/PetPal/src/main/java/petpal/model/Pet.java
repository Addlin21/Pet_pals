package petpal.model;

import lombok.*;
import java.time.LocalDate;
import java.util.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class Pet {
    private String name;
    private int age;
    private String breed;
    private PetType petType;
}
