package petpal.dao;

import java.util.List;

public interface AdoptionEventDao {
	List<String> getUpcomingEvents();
    void registerParticipant(int eventId, String participantName);
    
    

}
