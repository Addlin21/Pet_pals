package petpal.dao;

import petpal.util.ConnectionHelper;
import petpal.dao.DonationDao;
import java.sql.Date;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.time.LocalDate;

import java.sql.Timestamp;
import java.time.LocalDateTime;

public class DonationDaoImpl implements DonationDao{
	@Override
	public void recordCashDonation(String donorName, double amount) {
	    String sql = "INSERT INTO donations (donorName, donationAmount, donationDate, donationType) VALUES (?, ?, ?, 'cash')";

	    try (Connection conn = ConnectionHelper.getConnection();
	         PreparedStatement ps = conn.prepareStatement(sql)) {

	        ps.setString(1, donorName);
	        ps.setDouble(2, amount);
	        ps.setTimestamp(3, Timestamp.valueOf(LocalDateTime.now()));

	        int rows = ps.executeUpdate();
	        System.out.println(rows > 0 ? "✅ Cash donation recorded." : "❌ Donation failed.");

	    } catch (SQLException e) {
	        System.out.println("❌ Error recording donation: " + e.getMessage());
	    }
	}
	
	@Override
	public void recordItemDonation(String donorName, double amount, String itemType) {
	    String sql = "INSERT INTO donations (donorName, donationAmount, donationDate, donationType, donationitem) VALUES (?, ?, ?, 'item', ?)";

	    try (Connection conn = ConnectionHelper.getConnection();
	         PreparedStatement ps = conn.prepareStatement(sql)) {

	        ps.setString(1, donorName);
	        ps.setDouble(2, amount);
	        ps.setTimestamp(3, Timestamp.valueOf(LocalDateTime.now()));
	        ps.setString(4, itemType);  // Using 'donationitem' here

	        int rows = ps.executeUpdate();
	        System.out.println(rows > 0 ? "✅ Item donation recorded." : "❌ Donation failed.");

	    } catch (SQLException e) {
	        System.out.println("❌ Error recording item donation: " + e.getMessage());
	    }
	}


}
