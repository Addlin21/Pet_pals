package petpal.dao;

import java.util.List;
import petpal.model.Pet;

public interface IPetDao {
	void addPet(Pet pet); 
	boolean removePetByName(String name);
	List<Pet> getAvailablePets();

}
