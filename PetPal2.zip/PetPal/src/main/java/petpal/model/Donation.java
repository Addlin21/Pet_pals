package petpal.model;

import lombok.*;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public abstract class Donation {
    private String donorName;
    private double amount;

    public abstract void recordDonation();
}