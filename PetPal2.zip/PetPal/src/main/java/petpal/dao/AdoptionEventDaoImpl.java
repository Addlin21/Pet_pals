package petpal.dao;

import petpal.util.ConnectionHelper;
import petpal.dao.AdoptionEventDao;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class AdoptionEventDaoImpl implements AdoptionEventDao{
	
	@Override
	public List<String> getUpcomingEvents() {
	    List<String> events = new ArrayList<>();
	    String sql = "SELECT eventid, eventname, eventdate, location FROM adoptionevents WHERE eventdate >= CURDATE()";

	    try (Connection conn = ConnectionHelper.getConnection();
	         PreparedStatement ps = conn.prepareStatement(sql);
	         ResultSet rs = ps.executeQuery()) {

	        while (rs.next()) {
	            String event = "ID: " + rs.getInt("eventid") + 
	                           ", Name: " + rs.getString("eventname") + 
	                           ", Date: " + rs.getTimestamp("eventdate") + 
	                           ", Location: " + rs.getString("location");
	            events.add(event);
	        }

	    } catch (SQLException e) {
	        System.out.println("Error fetching events: " + e.getMessage());
	    }

	    return events;
	}


	
	@Override
	public void registerParticipant(int eventId, String participantName) {
	    String sql = "INSERT INTO participants (participantname, participanttype, eventid) VALUES (?, ?, ?)";

	    try (Connection conn = ConnectionHelper.getConnection();
	         PreparedStatement ps = conn.prepareStatement(sql)) {

	        // Assuming 'adopter' as a default participant type, modify if needed
	        ps.setString(1, participantName);
	        ps.setString(2, "adopter");  // or set based on logic (shelter/adopter)
	        ps.setInt(3, eventId);

	        int rows = ps.executeUpdate();
	        System.out.println(rows > 0 ? "Participant registered successfully." : "Registration failed.");

	    } catch (SQLException e) {
	        System.out.println("Error registering participant: " + e.getMessage());
	    }
	}


}
