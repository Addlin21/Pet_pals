package petpal.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.ResourceBundle;

public class ConnectionHelper {
	public static Connection getConnection() throws SQLException {
        try {
            ResourceBundle rb = ResourceBundle.getBundle("pet_adoption");
            String driver = rb.getString("driver");
            String url = rb.getString("url");
            String user = rb.getString("user");
            String pwd = rb.getString("password");

            Class.forName(driver);
            return DriverManager.getConnection(url, user, pwd);
        } catch (ClassNotFoundException e) {
            // Wrap in unchecked exception or custom exception if needed
            throw new RuntimeException("JDBC Driver not found", e);
        }
    }

}
