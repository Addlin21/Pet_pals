package petpal.exception;

public class AdoptionException extends Exception{
	public AdoptionException(String message) {
        super(message);
    }

}
