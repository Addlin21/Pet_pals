package petpal.dao;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.MockedStatic;
import petpal.util.ConnectionHelper;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.Timestamp;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class DonationDaoImplTest {

    private DonationDaoImpl dao;
    private Connection mockConnection;
    private PreparedStatement mockPreparedStatement;

    @BeforeEach
    public void setUp() {
        dao = new DonationDaoImpl();
        mockConnection = mock(Connection.class);
        mockPreparedStatement = mock(PreparedStatement.class);
    }

    @Test
    public void testRecordCashDonation_success() throws Exception {
        try (MockedStatic<ConnectionHelper> mocked = mockStatic(ConnectionHelper.class)) {
            mocked.when(ConnectionHelper::getConnection).thenReturn(mockConnection);
            when(mockConnection.prepareStatement(any(String.class))).thenReturn(mockPreparedStatement);
            when(mockPreparedStatement.executeUpdate()).thenReturn(1);

            dao.recordCashDonation("Alice", 200.00);

            verify(mockPreparedStatement).setString(1, "Alice");
            verify(mockPreparedStatement).setDouble(2, 200.00);
            verify(mockPreparedStatement).setTimestamp(eq(3), any(Timestamp.class));
            verify(mockPreparedStatement).executeUpdate();
        }
    }

    @Test
    public void testRecordItemDonation_success() throws Exception {
        try (MockedStatic<ConnectionHelper> mocked = mockStatic(ConnectionHelper.class)) {
            mocked.when(ConnectionHelper::getConnection).thenReturn(mockConnection);
            when(mockConnection.prepareStatement(any(String.class))).thenReturn(mockPreparedStatement);
            when(mockPreparedStatement.executeUpdate()).thenReturn(1);

            dao.recordItemDonation("Bob", 150.00, "Dog Food");

            verify(mockPreparedStatement).setString(1, "Bob");
            verify(mockPreparedStatement).setDouble(2, 150.00);
            verify(mockPreparedStatement).setTimestamp(eq(3), any(Timestamp.class));
            verify(mockPreparedStatement).setString(4, "Dog Food");
            verify(mockPreparedStatement).executeUpdate();
        }
    }
}
