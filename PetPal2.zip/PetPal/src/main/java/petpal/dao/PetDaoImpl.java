package petpal.dao;

import petpal.model.Pet;
import petpal.model.PetType;
import petpal.util.ConnectionHelper;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class PetDaoImpl implements IPetDao {

	@Override
	public void addPet(Pet pet) {
	    String sql = "INSERT INTO pets (name, age, breed, type, available) VALUES (?, ?, ?, ?, true)";

	    try (Connection conn = ConnectionHelper.getConnection();
	         PreparedStatement ps = conn.prepareStatement(sql)) {

	        ps.setString(1, pet.getName());
	        ps.setInt(2, pet.getAge());
	        ps.setString(3, pet.getBreed());

	        // Store type based on PetType enum
	        if (pet.getPetType() != null) {
	            ps.setString(4, pet.getPetType().name().toLowerCase()); // store as "dog" or "cat"
	        } else {
	            ps.setNull(4, java.sql.Types.VARCHAR);
	        }

	        int rows = ps.executeUpdate();
	        System.out.println(rows > 0 ? "✅ Pet added to database." : "❌ Failed to add pet.");

	    } catch (SQLException e) {
	        System.out.println("❌ Error adding pet: " + e.getMessage());
	    }
	}

	
	@Override
	public boolean removePetByName(String name) {
	    String sql = "UPDATE pets SET available = false WHERE name = ? AND available = true";

	    try (Connection conn = ConnectionHelper.getConnection();
	         PreparedStatement ps = conn.prepareStatement(sql)) {

	        ps.setString(1, name);
	        int rowsAffected = ps.executeUpdate();

	        if (rowsAffected > 0) {
	            System.out.println("✅ Pet marked as unavailable in database.");
	            return true;
	        } else {
	            System.out.println("⚠️ Pet not found or already unavailable.");
	            return false;
	        }

	    } catch (SQLException e) {
	        System.out.println("❌ Error removing pet: " + e.getMessage());
	        return false;
	    }
	}


	@Override
	public List<Pet> getAvailablePets() {
	    List<Pet> pets = new ArrayList<>();
	    String query = "SELECT name, age, breed, type FROM pets WHERE available = true";

	    try (Connection conn = ConnectionHelper.getConnection();
	         PreparedStatement stmt = conn.prepareStatement(query);
	         ResultSet rs = stmt.executeQuery()) {

	        while (rs.next()) {
	            String typeStr = rs.getString("type");
	            PetType petType = null;

	            if (typeStr != null && !typeStr.trim().isEmpty()) {
	                try {
	                    petType = PetType.valueOf(typeStr.toUpperCase()); // matches enum
	                } catch (IllegalArgumentException e) {
	                    System.out.println("⚠️ Invalid type in DB: " + typeStr);
	                }
	            }

	            Pet pet = new Pet(
	                    rs.getString("name"),
	                    rs.getInt("age"),
	                    rs.getString("breed"),
	                    petType
	            );
	            pets.add(pet);
	        }

	    } catch (SQLException e) {
	        System.out.println("❌ Error fetching pet listings: " + e.getMessage());
	    }

	    return pets;
	}


}
