package petpal.model;

import lombok.*;

import java.util.ArrayList;
import java.util.List;

@Getter
@Setter
@NoArgsConstructor
@ToString
public class AdoptionEvent {
    private List<IAdoptable> participants = new ArrayList<>();

    public void registerParticipant(IAdoptable participant) {
        participants.add(participant);
        System.out.println("Participant registered: " + participant);
    }

    public void hostEvent() {
        System.out.println("Hosting adoption event with " + participants.size() + " participants.");
        for (IAdoptable participant : participants) {
            participant.adopt();
        }
    }
}