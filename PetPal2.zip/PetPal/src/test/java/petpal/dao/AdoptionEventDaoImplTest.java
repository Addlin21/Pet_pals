package petpal.dao;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.MockedStatic;
import petpal.util.ConnectionHelper;

import java.sql.*;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class AdoptionEventDaoImplTest {

    private AdoptionEventDaoImpl dao;
    private Connection mockConnection;
    private PreparedStatement mockPreparedStatement;
    private ResultSet mockResultSet;

    @BeforeEach
    public void setUp() throws Exception {
        dao = new AdoptionEventDaoImpl();

        mockConnection = mock(Connection.class);
        mockPreparedStatement = mock(PreparedStatement.class);
        mockResultSet = mock(ResultSet.class);
    }

    @Test
    public void testGetUpcomingEvents_returnsFormattedEventList() throws Exception {
        String expectedEvent = "ID: 1, Name: Adoption Fair, Date: 2025-04-10 10:00:00.0, Location: Downtown Park";

        try (MockedStatic<ConnectionHelper> mocked = mockStatic(ConnectionHelper.class)) {
            mocked.when(ConnectionHelper::getConnection).thenReturn(mockConnection);

            when(mockConnection.prepareStatement(any(String.class))).thenReturn(mockPreparedStatement);
            when(mockPreparedStatement.executeQuery()).thenReturn(mockResultSet);

            when(mockResultSet.next()).thenReturn(true).thenReturn(false);
            when(mockResultSet.getInt("eventid")).thenReturn(1);
            when(mockResultSet.getString("eventname")).thenReturn("Adoption Fair");
            when(mockResultSet.getTimestamp("eventdate")).thenReturn(Timestamp.valueOf("2025-04-10 10:00:00"));
            when(mockResultSet.getString("location")).thenReturn("Downtown Park");

            List<String> events = dao.getUpcomingEvents();

            assertNotNull(events);
            assertEquals(1, events.size());
            assertEquals(expectedEvent, events.get(0));
        }
    }

    @Test
    public void testRegisterParticipant_executesInsertSuccessfully() throws Exception {
        try (MockedStatic<ConnectionHelper> mocked = mockStatic(ConnectionHelper.class)) {
            mocked.when(ConnectionHelper::getConnection).thenReturn(mockConnection);

            when(mockConnection.prepareStatement(any(String.class))).thenReturn(mockPreparedStatement);
            when(mockPreparedStatement.executeUpdate()).thenReturn(1);

            dao.registerParticipant(1, "John Doe");

            verify(mockPreparedStatement).setString(1, "John Doe");
            verify(mockPreparedStatement).setString(2, "adopter");
            verify(mockPreparedStatement).setInt(3, 1);
            verify(mockPreparedStatement).executeUpdate();
        }
    }
}
