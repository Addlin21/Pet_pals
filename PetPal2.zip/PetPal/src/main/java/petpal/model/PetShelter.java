package petpal.model;

import lombok.*;

import java.util.ArrayList;
import java.util.List;

@Getter
@Setter
@NoArgsConstructor
@ToString
public class PetShelter {
    private List<Pet> availablePets = new ArrayList<>();

    public void addPet(Pet pet) {
        availablePets.add(pet);
    }

    public void removePet(Pet pet) {
        availablePets.remove(pet);
    }

    public void listAvailablePets() {
        for (Pet pet : availablePets) {
            System.out.println(pet);
        }
    }
    
    public void setAvailablePets(List<Pet> pets) {
        this.availablePets = pets;
    }

}
