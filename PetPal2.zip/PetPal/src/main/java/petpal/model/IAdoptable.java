package petpal.model;

public interface IAdoptable {
    void adopt();
}
