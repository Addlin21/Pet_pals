package petpal.model;

import lombok.*;
import java.time.LocalDate;
import java.util.*;


@Getter
@Setter
@NoArgsConstructor
@ToString(callSuper = true)
public class Cat extends Pet {
    private String catColor;

    public Cat(String name, int age, String breed, String catColor) {
    	super(name, age, breed, PetType.CAT);
        this.catColor = catColor;
    }
}