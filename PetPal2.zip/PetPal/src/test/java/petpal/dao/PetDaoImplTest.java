package petpal.dao;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.MockedStatic;
import petpal.model.Pet;
import petpal.model.PetType;
import petpal.util.ConnectionHelper;

import java.sql.*;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class PetDaoImplTest {

    private PetDaoImpl dao;
    private Connection mockConnection;
    private PreparedStatement mockPreparedStatement;
    private ResultSet mockResultSet;

    @BeforeEach
    public void setUp() throws Exception {
        dao = new PetDaoImpl();
        mockConnection = mock(Connection.class);
        mockPreparedStatement = mock(PreparedStatement.class);
        mockResultSet = mock(ResultSet.class);
    }

    @Test
    public void testAddPet_successfullyInsertsPet() throws Exception {
        Pet pet = new Pet("Buddy", 3, "Golden Retriever", PetType.DOG);

        try (MockedStatic<ConnectionHelper> mocked = mockStatic(ConnectionHelper.class)) {
            mocked.when(ConnectionHelper::getConnection).thenReturn(mockConnection);
            when(mockConnection.prepareStatement(anyString())).thenReturn(mockPreparedStatement);
            when(mockPreparedStatement.executeUpdate()).thenReturn(1);

            dao.addPet(pet);

            verify(mockPreparedStatement).setString(1, "Buddy");
            verify(mockPreparedStatement).setInt(2, 3);
            verify(mockPreparedStatement).setString(3, "Golden Retriever");
            verify(mockPreparedStatement).setString(4, "dog");
            verify(mockPreparedStatement).executeUpdate();
        }
    }

    @Test
    public void testRemovePetByName_petExists_returnsTrue() throws Exception {
        try (MockedStatic<ConnectionHelper> mocked = mockStatic(ConnectionHelper.class)) {
            mocked.when(ConnectionHelper::getConnection).thenReturn(mockConnection);
            when(mockConnection.prepareStatement(anyString())).thenReturn(mockPreparedStatement);
            when(mockPreparedStatement.executeUpdate()).thenReturn(1); // simulate pet found

            boolean result = dao.removePetByName("Buddy");

            assertTrue(result);
            verify(mockPreparedStatement).setString(1, "Buddy");
        }
    }

    @Test
    public void testRemovePetByName_petNotFound_returnsFalse() throws Exception {
        try (MockedStatic<ConnectionHelper> mocked = mockStatic(ConnectionHelper.class)) {
            mocked.when(ConnectionHelper::getConnection).thenReturn(mockConnection);
            when(mockConnection.prepareStatement(anyString())).thenReturn(mockPreparedStatement);
            when(mockPreparedStatement.executeUpdate()).thenReturn(0); // simulate no match

            boolean result = dao.removePetByName("Ghost");

            assertFalse(result);
        }
    }

    @Test
    public void testGetAvailablePets_returnsPetList() throws Exception {
        try (MockedStatic<ConnectionHelper> mocked = mockStatic(ConnectionHelper.class)) {
            mocked.when(ConnectionHelper::getConnection).thenReturn(mockConnection);
            when(mockConnection.prepareStatement(anyString())).thenReturn(mockPreparedStatement);
            when(mockPreparedStatement.executeQuery()).thenReturn(mockResultSet);

            // Mock resultSet
            when(mockResultSet.next()).thenReturn(true, false); // one row
            when(mockResultSet.getString("name")).thenReturn("Buddy");
            when(mockResultSet.getInt("age")).thenReturn(3);
            when(mockResultSet.getString("breed")).thenReturn("Golden Retriever");
            when(mockResultSet.getString("type")).thenReturn("dog");

            List<Pet> pets = dao.getAvailablePets();

            assertNotNull(pets);
            assertEquals(1, pets.size());
            Pet pet = pets.get(0);
            assertEquals("Buddy", pet.getName());
            assertEquals(3, pet.getAge());
            assertEquals("Golden Retriever", pet.getBreed());
            assertEquals(PetType.DOG, pet.getPetType());
        }
    }
}
