package petpal.exception;

public class NullReferenceException extends Exception{
	public NullReferenceException(String message) {
        super(message);
    }
	

}
